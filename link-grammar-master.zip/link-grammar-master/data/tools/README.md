
Dictionary Maintenance Tools
----------------------------

This directory contains some ad-hoc, undocumented tools for maintaining
the dictionaries.

Here are a few documented tools:

*  insert.pl: add words to a dictionary, in sorted alphabetical order.
*  delete.pl: remove words from a dictionary
*  fix-len.pl: reformat the dictionary files to have even line-lengths
