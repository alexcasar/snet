#! /usr/bin/env perl
#

use clinkgrammar;

$ver = clinkgrammar::linkgrammar_get_version();

print "Hello world, found version $ver\n";
