#include "variables.hpp"

#ifdef _VARS
std::ostream& var_defs_stream = cout;
#endif
