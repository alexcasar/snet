

void classic_parse(Sentence, Parse_Options);
